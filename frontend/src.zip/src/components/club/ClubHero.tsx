import { useRef, useState } from 'react';
import {
    CalendarDays,
    Camera,
    Check,
    Loader2,
    LogOut,
    MapPin,
    MessageSquare,
    Plus,
    Settings,
    ShieldCheck,
    Swords,
    Users
} from 'lucide-react';
import { apiClient } from '../../api/axiosConfig';
import { PageHeroSection } from '../layout/PageHeroSection';
import { clubRoleLabel } from '../../features/clubs/domain';
import { getCroppedImg } from '../../utils/cropImageHelper';
import { resolveMediaUrl } from '../../utils/resolveMediaUrl';
import { ImageCropperModal } from '../../ui/ImageCropperModal';
import type { ClubProfile } from '../../pages/ClubProfilePage';

interface ClubHeroProps {
    club: ClubProfile | null;
    canEditClubAssets: boolean;
    canManageClub: boolean;
    canOpenCalendar: boolean;
    canChallengeClub: boolean;
    canMessageClub: boolean;
    membershipRole?: string | null;
    showInlineLeaveAction?: boolean;
    onFollowToggle: () => void;
    onOpenManageClub: () => void;
    onOpenCalendar: () => void;
    onOpenChallengeModal: () => void;
    onOpenMessage: () => void;
    onLeaveClub?: () => Promise<void> | void;
    onRefresh: () => void;
}

export const ClubHero = ({
    club,
    canEditClubAssets,
    canManageClub,
    canOpenCalendar,
    canChallengeClub,
    canMessageClub,
    membershipRole,
    showInlineLeaveAction = false,
    onFollowToggle,
    onOpenManageClub,
    onOpenCalendar,
    onOpenChallengeModal,
    onOpenMessage,
    onLeaveClub,
    onRefresh
}: ClubHeroProps) => {
    const bannerInputRef = useRef<HTMLInputElement>(null);
    const logoInputRef = useRef<HTMLInputElement>(null);
    const [uploading, setUploading] = useState<'banner' | 'logo' | null>(null);
    const [cropperModal, setCropperModal] = useState<{ isOpen: boolean; imageUrl: string; type: 'banner' | 'logo' } | null>(null);
    const [isConfirmingLeave, setIsConfirmingLeave] = useState(false);
    const [isLeavingClub, setIsLeavingClub] = useState(false);
    const [leaveError, setLeaveError] = useState<string | null>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>, type: 'banner' | 'logo') => {
        const file = event.target.files?.[0];
        if (!file) return;
        const imageUrl = URL.createObjectURL(file);
        setCropperModal({ isOpen: true, imageUrl, type });
        if (event.target) event.target.value = '';
    };

    const handleCropComplete = async (croppedAreaPixels: any) => {
        if (!cropperModal || !club?.id) return;
        setUploading(cropperModal.type);
        const type = cropperModal.type;
        setCropperModal(null);

        try {
            const croppedImageBlob = await getCroppedImg(cropperModal.imageUrl, croppedAreaPixels);
            if (!croppedImageBlob) throw new Error('Failed to crop image.');

            const formData = new FormData();
            formData.append('file', croppedImageBlob, `${type}.jpg`);

            const uploadResponse = await apiClient.post('/media/upload', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            const mediaUrl = uploadResponse.data?.url;
            if (!mediaUrl) {
                throw new Error('Media upload did not return a URL.');
            }

            await apiClient.put(`/clubs/${club.id}`, type === 'banner' ? { bannerUrl: mediaUrl } : { logoUrl: mediaUrl });
            onRefresh();
        } catch (error) {
            console.error(`Failed to upload ${type}`, error);
        } finally {
            setUploading(null);
        }
    };

    const handleLeaveClub = async () => {
        if (!onLeaveClub) return;
        setIsLeavingClub(true);
        setLeaveError(null);

        try {
            await onLeaveClub();
            setIsConfirmingLeave(false);
        } catch (error) {
            console.error('Failed to leave club', error);
            setLeaveError('Failed to leave this club.');
        } finally {
            setIsLeavingClub(false);
        }
    };

    const bannerUrl = resolveMediaUrl(club?.bannerUrl);
    const logoUrl = resolveMediaUrl(club?.logoUrl);
    const showExternalVisitorActions = Boolean(club && !club.isMember);
    const systemActionClassName = 'club-action-button club-action-button--system inline-flex items-center gap-2 rounded-[4px] px-4 py-2.5 text-[10px] font-black uppercase tracking-[0.16em]';
    const accentActionClassName = 'club-action-button club-action-button--primary inline-flex items-center gap-2 rounded-[4px] px-4 py-2.5 text-[10px] font-black uppercase tracking-[0.16em]';
    const challengeActionClassName = 'club-action-button club-action-button--danger inline-flex items-center gap-2 rounded-[4px] px-4 py-2.5 text-[10px] font-black uppercase tracking-[0.16em]';
    const destructiveActionClassName =
        'club-action-button club-action-button--soft-danger inline-flex items-center gap-2 rounded-[4px] px-4 py-2.5 text-[10px] font-black uppercase tracking-[0.16em]';

    return (
        <section className="bg-[color:var(--club-band)]">
            <div className="relative h-48 overflow-hidden border-b border-subtle sm:h-56 lg:h-[320px]">
                {bannerUrl ? (
                    <img src={bannerUrl} alt="Club banner" className="h-full w-full object-cover" />
                ) : (
                    <div className="club-banner-fallback h-full w-full" />
                )}

                <div className="club-banner-scrim absolute inset-0" />

                {canEditClubAssets && (
                    <div className="absolute right-5 top-5 z-10">
                        <input type="file" ref={bannerInputRef} className="hidden" accept="image/jpeg,image/png,image/webp" onChange={(event) => handleFileChange(event, 'banner')} />
                        <button
                            type="button"
                            onClick={() => bannerInputRef.current?.click()}
                            disabled={uploading === 'banner'}
                            className="club-upload-button inline-flex items-center gap-2 rounded-[4px] px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] backdrop-blur-md"
                        >
                            {uploading === 'banner' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
                            Banner
                        </button>
                    </div>
                )}
            </div>

            <PageHeroSection className="bg-[color:var(--club-band)]" frameClassName="club-page-frame relative py-8 lg:py-10">
                <div className="flex flex-col gap-8 xl:flex-row xl:items-end xl:justify-between">
                    <div className="flex items-end gap-5">
                        <div className="relative -mt-[72px] shrink-0 sm:-mt-[88px] lg:-mt-[104px]">
                            <div className="flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border-[4px] border-[color:var(--club-band)] bg-base text-2xl font-black uppercase text-primary shadow-float sm:h-28 sm:w-28 lg:h-36 lg:w-36">
                                {logoUrl ? <img src={logoUrl} alt="Club logo" className="h-full w-full object-cover" /> : (club?.name ?? 'CL').substring(0, 2).toUpperCase()}
                            </div>
                            {canEditClubAssets && (
                                <>
                                    <input type="file" ref={logoInputRef} className="hidden" accept="image/jpeg,image/png,image/webp" onChange={(event) => handleFileChange(event, 'logo')} />
                                    <button
                                        type="button"
                                        onClick={() => logoInputRef.current?.click()}
                                        className="club-upload-button absolute -bottom-1 -right-1 inline-flex h-9 w-9 items-center justify-center rounded-[4px]"
                                    >
                                        {uploading === 'logo' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
                                    </button>
                                </>
                            )}
                        </div>

                        <div className="min-w-0 pb-2">
                            <div className="mt-2 flex flex-wrap items-center gap-2">
                                <h1 className="text-3xl font-black uppercase tracking-tight text-primary sm:text-4xl">{club?.name}</h1>
                                {club?.isOfficial && (
                                    <span className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase tracking-[0.18em] text-[color:var(--club-tone-green)]">
                                        <ShieldCheck className="h-4 w-4" />
                                    </span>
                                )}
                            </div>

                            <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-2 text-[11px] font-black uppercase tracking-[0.18em] text-secondary">
                                <span className="inline-flex items-center gap-1.5">
                                    <MapPin className="h-3.5 w-3.5 text-[color:var(--club-tone-green)]" />
                                    {club?.addressText || 'Location pending'}
                                </span>
                                <span className="h-1 w-1 rounded-full bg-[color:var(--club-divider-dot)]" />
                                <span className="text-[color:var(--club-tone-green)]">{club?.type || 'Club profile'}</span>
                                {membershipRole && (
                                    <>
                                        <span className="h-1 w-1 rounded-full bg-[color:var(--club-divider-dot)]" />
                                        <span className="inline-flex items-center gap-1.5 text-primary">
                                            <Users className="h-3.5 w-3.5 text-[color:var(--club-tone-blue)]" />
                                            {clubRoleLabel(membershipRole)}
                                        </span>
                                    </>
                                )}
                            </div>

                            {club?.description && (
                                <p className="mt-4 max-w-3xl text-sm leading-6 text-secondary">{club.description}</p>
                            )}
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 xl:justify-end">
                        {canManageClub ? (
                            <>
                                {canOpenCalendar && (
                                    <button type="button" onClick={onOpenCalendar} className={systemActionClassName}>
                                        <CalendarDays className="h-4 w-4 text-[color:var(--club-system-action-icon)]" />
                                        Schedule
                                    </button>
                                )}
                                <button type="button" onClick={onOpenManageClub} className={systemActionClassName}>
                                    <Settings className="h-4 w-4 text-[color:var(--club-system-action-icon)]" />
                                    Manage Club
                                </button>
                            </>
                        ) : showExternalVisitorActions ? (
                            <>
                                {canChallengeClub && (
                                    <button type="button" onClick={onOpenChallengeModal} className={challengeActionClassName}>
                                        <Swords className="h-4 w-4" />
                                        Challenge
                                    </button>
                                )}
                                {canMessageClub && (
                                    <button
                                        type="button"
                                        onClick={onOpenMessage}
                                        className={systemActionClassName}
                                    >
                                        <MessageSquare className="h-4 w-4 text-[color:var(--club-system-action-icon)]" />
                                        Message
                                    </button>
                                )}
                                <button
                                    type="button"
                                    onClick={onFollowToggle}
                                    className={`${club?.isFollowedByMe ? accentActionClassName : accentActionClassName}`.trim()}
                                >
                                    {club?.isFollowedByMe ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                                    {club?.isFollowedByMe ? 'Following' : 'Follow'}
                                </button>
                            </>
                        ) : null}

                        {showInlineLeaveAction && (
                            isConfirmingLeave ? (
                                <>
                                    <button type="button" onClick={() => setIsConfirmingLeave(false)} disabled={isLeavingClub} className={systemActionClassName}>
                                        Cancel
                                    </button>
                                    <button type="button" onClick={() => void handleLeaveClub()} disabled={isLeavingClub} className={destructiveActionClassName}>
                                        {isLeavingClub ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogOut className="h-4 w-4" />}
                                        Confirm Leave
                                    </button>
                                </>
                            ) : (
                                <button type="button" onClick={() => setIsConfirmingLeave(true)} className={destructiveActionClassName}>
                                    <LogOut className="h-4 w-4" />
                                    Leave Club
                                </button>
                            )
                        )}
                    </div>
                </div>

                {leaveError && (
                    <div className="mt-6 border border-[color:var(--state-danger)] bg-[color:var(--state-danger-soft)] px-4 py-3 text-sm font-semibold text-[color:var(--state-danger)]">
                        {leaveError}
                    </div>
                )}
            </PageHeroSection>

            {cropperModal && (
                <ImageCropperModal
                    isOpen={cropperModal.isOpen}
                    imageUrl={cropperModal.imageUrl}
                    title={cropperModal.type === 'banner' ? 'Adjust Cover Photo' : 'Adjust Club Logo'}
                    aspectRatio={cropperModal.type === 'banner' ? 3 / 1 : 1 / 1}
                    onClose={() => setCropperModal(null)}
                    onCropComplete={handleCropComplete}
                    isProcessing={uploading !== null}
                />
            )}
        </section>
    );
};
