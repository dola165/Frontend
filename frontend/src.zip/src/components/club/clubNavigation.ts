import { BriefcaseBusiness, CalendarDays, LayoutDashboard, Trophy, Users } from 'lucide-react';

export type ClubNavigationTab = 'overview' | 'squads' | 'honours' | 'opportunities' | 'calendar';

export interface ClubNavigationClubSummary {
    honours?: Array<unknown>;
    opportunities?: Array<unknown>;
}

export interface ClubNavigationItem {
    id: ClubNavigationTab;
    label: string;
    icon: typeof LayoutDashboard;
    badge?: (club: ClubNavigationClubSummary) => number | null;
    toneClassName: string;
}

export const clubNavigationItems: ClubNavigationItem[] = [
    {
        id: 'overview',
        icon: LayoutDashboard,
        label: 'Our Club',
        toneClassName: 'club-tone-green'
    },
    {
        id: 'honours',
        icon: Trophy,
        label: 'Honours',
        badge: (club) => club.honours?.length ?? null,
        toneClassName: 'club-tone-cyan'
    },
    {
        id: 'squads',
        icon: Users,
        label: 'Teams',
        toneClassName: 'club-tone-blue'
    },
    {
        id: 'calendar',
        icon: CalendarDays,
        label: 'Schedule',
        toneClassName: 'club-tone-purple'
    },
    {
        id: 'opportunities',
        icon: BriefcaseBusiness,
        label: 'Business',
        badge: (club) => club.opportunities?.length ?? null,
        toneClassName: 'club-tone-violet'
    }
];
