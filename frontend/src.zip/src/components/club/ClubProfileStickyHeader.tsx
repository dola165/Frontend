import { BellRing } from 'lucide-react';
import type { ClubTab } from '../../pages/ClubProfilePage';
import { clubNavigationItems } from './clubNavigation';

interface ClubProfileStickyHeaderProps {
    activeTab: ClubTab;
    onTabChange: (tab: ClubTab) => void;
    club: {
        honours?: Array<unknown>;
        opportunities?: Array<unknown>;
    };
    canManageClub?: boolean;
    onOpenNotifications?: () => void;
}

export const ClubProfileStickyHeader = ({
    activeTab,
    onTabChange,
    club,
    canManageClub = false,
    onOpenNotifications
}: ClubProfileStickyHeaderProps) => (
    <div className="club-top-nav-shell lg:sticky lg:top-[calc(var(--app-header-height)+1px)]">
        <div className="club-top-nav-strip overflow-x-auto">
            <div className="flex min-w-max items-stretch gap-2 px-2 py-3">
                {clubNavigationItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = item.id === activeTab;
                    const badge = item.badge?.(club) ?? null;

                    return (
                        <button
                            key={item.id}
                            type="button"
                            onClick={() => onTabChange(item.id)}
                            className={`club-sidebar-item ${item.toneClassName} inline-flex items-center justify-between gap-3 rounded-[4px] px-4 py-3 text-left transition-all ${isActive ? 'club-sidebar-item--active' : ''}`}
                        >
                            <span className="flex items-center gap-3">
                                <Icon className="h-4 w-4" />
                                <span className="text-[11px] font-black uppercase tracking-[0.16em]">{item.label}</span>
                            </span>

                            {badge != null && badge > 0 ? (
                                <span className={`club-sidebar-badge rounded-[4px] border px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] ${isActive ? 'club-sidebar-badge--active' : 'border-subtle text-secondary'}`}>
                                    {badge}
                                </span>
                            ) : null}
                        </button>
                    );
                })}

                {canManageClub && onOpenNotifications ? (
                    <button
                        type="button"
                        onClick={onOpenNotifications}
                        className="club-sidebar-item club-tone-blue inline-flex items-center gap-3 rounded-[4px] px-4 py-3 text-left transition-all"
                    >
                        <BellRing className="h-4 w-4" />
                        <span className="text-[11px] font-black uppercase tracking-[0.16em]">Notifications</span>
                    </button>
                ) : null}
            </div>
        </div>
    </div>
);
