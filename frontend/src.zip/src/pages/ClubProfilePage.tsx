import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { apiClient } from '../api/axiosConfig';
import { ClubHero } from '../components/club/ClubHero';
import { ClubProfileInfoPanel } from '../components/club/ClubProfileInfoPanel';
import { ClubOpportunities } from '../components/club/ClubOpportunities';
import { ClubProfileStickyHeader } from '../components/club/ClubProfileStickyHeader';
import type { ClubNavigationTab } from '../components/club/clubNavigation';
import { MatchInviteModal, type MatchChallengePayload } from '../components/club/MatchInviteModal';
import { ClubManagementModal, type ClubManagementTab } from '../components/club/ClubManagementModal';
import { ClubMessageModal, buildClubCommunicationOptions, openClubCommunication } from '../components/club/ClubMessageModal';
import { TabTeams } from '../components/club/tabs/TabTeams';
import { TabOverview } from '../components/club/tabs/TabOverview';
import { TabHonours } from '../components/club/tabs/TabHonours';
import { TabOpportunities } from '../components/club/tabs/TabOpportunities';
import { TabCalendar } from '../components/club/tabs/TabCalendar';
import {
    canManageClubOperations,
    isLeadershipRole,
    type ClubRelationshipState,
    type ClubMembershipRole
} from '../features/clubs/domain';
import { fetchMyClubMembershipContext, leaveClubMembership } from '../features/clubs/api';
import { ClubApplicationPanel } from '../features/applications/components/ClubApplicationPanel';
import { createNotificationSearch } from '../utils/notifications';
import { useAuth } from '../context/AuthContext';
import { buildLoginRedirectPath } from '../utils/authRedirect';
import { AppPageFrame, AppPageShell } from '../components/layout/AppPageShell';

export interface ClubOpportunity {
    id: number;
    type: 'FUNDRAISING' | 'JOB' | 'VOLUNTEER' | 'WISHLIST';
    title: string;
    externalLink: string;
}

export interface ClubHonour {
    id: number;
    title: string;
    yearWon: number;
    description?: string | null;
}

export interface ClubProfile {
    id: number;
    name: string;
    description: string;
    type: string;
    isOfficial: boolean;
    statusLabel: string;
    followerCount: number;
    memberCount: number;
    isFollowedByMe: boolean;
    isMember: boolean;
    myRole?: ClubMembershipRole | null;
    relationshipState?: ClubRelationshipState | null;
    pendingApplicationId?: number | null;
    pendingApplicationRole?: ClubMembershipRole | null;
    addressText?: string;
    logoUrl?: string;
    bannerUrl?: string;
    whatsappNumber?: string | null;
    facebookMessengerUrl?: string | null;
    preferredCommunicationMethod?: string | null;
    latitude?: number;
    longitude?: number;
    trustedByClubs: Array<{ clubId: number; clubName: string }>;
    honours: ClubHonour[];
    opportunities: ClubOpportunity[];
}

export type ClubTab = ClubNavigationTab;

const normalizeManagementTab = (value: string | null): ClubManagementTab | null =>
    value === 'personnel' || value === 'invites' || value === 'applications' || value === 'roles' || value === 'squads' || value === 'tryouts'
        ? value
        : null;

const normalizeTab = (value: string | null): ClubTab =>
    value === 'squads' || value === 'honours' || value === 'opportunities' || value === 'calendar' ? value : 'overview';

export const ClubProfilePage = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams, setSearchParams] = useSearchParams();
    const { status } = useAuth();

    const [club, setClub] = useState<ClubProfile | null>(null);
    const [loading, setLoading] = useState(true);
    const [myClubId, setMyClubId] = useState<number | null>(null);
    const [myClubRole, setMyClubRole] = useState<string | null>(null);
    const [squadsRefreshKey, setSquadsRefreshKey] = useState(0);
    const [isManageClubOpen, setIsManageClubOpen] = useState(false);
    const [isChallengeModalOpen, setIsChallengeModalOpen] = useState(false);
    const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);

    const activeTab = normalizeTab(searchParams.get('tab'));
    const requestedManagementTab = useMemo(() => normalizeManagementTab(searchParams.get('managementTab')), [searchParams]);

    const fetchClubData = async () => {
        setLoading(true);
        try {
            const response = await apiClient.get(`/clubs/${id}`);
            setClub(response.data);
        } catch (error) {
            console.error('Failed to fetch club', error);
        } finally {
            setLoading(false);
        }
    };

    const fetchUserContext = async () => {
        try {
            const membershipResponse = await fetchMyClubMembershipContext().catch(() => null);
            if (membershipResponse?.clubId) {
                setMyClubId(membershipResponse.clubId);
                setMyClubRole(membershipResponse.myRole ?? null);
            } else {
                setMyClubId(null);
                setMyClubRole(null);
            }
        } catch (error) {
            console.error('Failed to fetch user context', error);
        }
    };

    useEffect(() => {
        if (id) {
            void fetchClubData();
        }
    }, [id]);

    useEffect(() => {
        if (!id) return;
        if (status !== 'authenticated') {
            setMyClubId(null);
            setMyClubRole(null);
            return;
        }
        void fetchUserContext();
    }, [id, status]);

    const ownClubRole = club?.myRole ?? null;
    const isOwnClubAdmin = isLeadershipRole(ownClubRole);
    const canManageOwnClub = canManageClubOperations(ownClubRole);
    const canChallengeOtherClub = Boolean(myClubId && myClubId !== Number(id) && myClubRole && isLeadershipRole(myClubRole));
    const canOpenCalendar = isOwnClubAdmin;
    const communicationOptions = buildClubCommunicationOptions(club?.whatsappNumber, club?.facebookMessengerUrl, club?.preferredCommunicationMethod);
    const showVisitorActions = Boolean(club && !club.isMember);
    const canMessageClub = Boolean(showVisitorActions && canChallengeOtherClub && communicationOptions.length > 0);

    useEffect(() => {
        if (searchParams.get('manageClub') !== '1' || !canManageOwnClub) {
            return;
        }
        setIsManageClubOpen(true);
    }, [canManageOwnClub, searchParams]);

    const updateSearchParam = (key: string, value?: string | null) => {
        const nextSearchParams = new URLSearchParams(searchParams);
        if (value) {
            nextSearchParams.set(key, value);
        } else {
            nextSearchParams.delete(key);
        }
        setSearchParams(nextSearchParams, { replace: true });
    };

    const setActiveTab = (tab: ClubTab) => updateSearchParam('tab', tab === 'overview' ? null : tab);

    const openManageClub = (tab?: ClubManagementTab | null) => {
        const nextSearchParams = new URLSearchParams(searchParams);
        nextSearchParams.set('manageClub', '1');
        if (tab) {
            nextSearchParams.set('managementTab', tab);
        } else {
            nextSearchParams.delete('managementTab');
        }
        setSearchParams(nextSearchParams, { replace: true });
        setIsManageClubOpen(true);
    };

    const closeManageClub = () => {
        const nextSearchParams = new URLSearchParams(searchParams);
        nextSearchParams.delete('manageClub');
        nextSearchParams.delete('managementTab');
        setSearchParams(nextSearchParams, { replace: true });
        setIsManageClubOpen(false);
    };

    const handleFollowToggle = async () => {
        if (status !== 'authenticated') {
            navigate(buildLoginRedirectPath(location.pathname, location.search, location.hash));
            return;
        }

        try {
            await apiClient.post(`/clubs/${id}/follow`);
            await fetchClubData();
        } catch (error) {
            console.error('Failed to toggle follow', error);
        }
    };

    const handleChallengeSubmit = async (inviteData: MatchChallengePayload) => {
        try {
            await apiClient.post(`/clubs/${id}/challenge`, inviteData);
            setIsChallengeModalOpen(false);
        } catch (error) {
            console.error('Failed to send challenge', error);
            throw error;
        }
    };

    const handleOpenMessage = () => {
        if (communicationOptions.length === 1) {
            openClubCommunication(communicationOptions[0]);
            return;
        }
        if (communicationOptions.length > 1) {
            setIsMessageModalOpen(true);
        }
    };

    const handleMembershipLeft = async () => {
        closeManageClub();
        await Promise.all([fetchClubData(), fetchUserContext()]);
        setSquadsRefreshKey((current) => current + 1);
    };

    const handleLeaveOwnClub = async () => {
        if (!club) return;
        await leaveClubMembership(club.id);
        await handleMembershipLeft();
    };

    if (loading) {
        return (
            <div className="club-page-shell bg-base flex h-full min-h-[calc(100vh-var(--app-header-height))] items-center justify-center">
                <div className="h-12 w-12 animate-spin rounded-full border-4 border-accent-primary border-t-transparent"></div>
            </div>
        );
    }

    if (!club) {
        return (
            <div className="club-page-shell bg-base flex h-full min-h-[calc(100vh-var(--app-header-height))] items-center justify-center px-6">
                <div className="bg-surface border border-subtle px-8 py-10 text-center">
                    <ShieldCheck className="mx-auto mb-4 h-12 w-12 accent-primary" />
                    <h2 className="text-xl font-black uppercase tracking-[0.18em] text-primary">Club Not Found</h2>
                    <button type="button" onClick={() => navigate(-1)} className="mt-4 text-sm font-black uppercase tracking-[0.16em] accent-primary">
                        Go Back
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="club-page-shell bg-base min-h-full">
            <ClubHero
                club={club}
                canEditClubAssets={isOwnClubAdmin}
                canManageClub={canManageOwnClub}
                canOpenCalendar={canOpenCalendar}
                canChallengeClub={showVisitorActions && canChallengeOtherClub}
                canMessageClub={canMessageClub}
                membershipRole={ownClubRole ?? null}
                showInlineLeaveAction={ownClubRole === 'PLAYER' || ownClubRole === 'COACH'}
                onFollowToggle={handleFollowToggle}
                onOpenCalendar={() => setActiveTab('calendar')}
                onOpenManageClub={() => openManageClub()}
                onOpenChallengeModal={() => setIsChallengeModalOpen(true)}
                onOpenMessage={handleOpenMessage}
                onLeaveClub={handleLeaveOwnClub}
                onRefresh={fetchClubData}
            />

            <AppPageShell
                shellClassName="club-page-shell bg-transparent"
                beforeContent={(
                    <>
                        <AppPageFrame className="club-page-frame pt-0">
                            <div className="club-profile-top-grid">
                                <div className="club-profile-top-span">
                                    <ClubProfileStickyHeader
                                        activeTab={activeTab}
                                        onTabChange={setActiveTab}
                                        club={club}
                                        canManageClub={canManageOwnClub}
                                        onOpenNotifications={
                                            canManageOwnClub
                                                ? () => navigate(`/notifications?${createNotificationSearch('club', club.id, club.name)}`)
                                                : undefined
                                        }
                                    />
                                </div>
                            </div>
                        </AppPageFrame>

                        {!club.isMember ? (
                            <AppPageFrame className="pt-6">
                                <ClubApplicationPanel
                                    clubId={club.id}
                                    clubName={club.name}
                                    isAuthenticated={status === 'authenticated'}
                                    relationshipState={club.relationshipState ?? null}
                                    pendingApplicationId={club.pendingApplicationId ?? null}
                                    pendingApplicationRole={club.pendingApplicationRole ?? null}
                                    activeClubId={myClubId}
                                    onOpenInvites={() => navigate('/my-club')}
                                    onSignIn={() => navigate(buildLoginRedirectPath(location.pathname, location.search, location.hash))}
                                    onStateChange={(nextState) => {
                                        setClub((current) => current ? {
                                            ...current,
                                            relationshipState: nextState.relationshipState,
                                            pendingApplicationId: nextState.pendingApplicationId ?? null,
                                            pendingApplicationRole: nextState.pendingApplicationRole ?? null
                                        } : current);
                                    }}
                                />
                            </AppPageFrame>
                        ) : null}
                    </>
                )}
                frameClassName="club-page-frame club-profile-frame py-6"
                gridClassName="club-profile-main-grid"
                leftClassName="club-profile-left px-0 py-0"
                left={(
                    <ClubProfileInfoPanel club={club} />
                )}
                center={(
                    <div className="flex min-w-0 flex-col gap-4">
                        {activeTab === 'overview' && (
                            <TabOverview club={club} isOwnClubAdmin={isOwnClubAdmin} />
                        )}
                        {activeTab === 'squads' && (
                            <TabTeams clubId={club.id} refreshKey={squadsRefreshKey} />
                        )}
                        {activeTab === 'honours' && <TabHonours club={club} />}
                        {activeTab === 'opportunities' && <TabOpportunities club={club} isOwnClubAdmin={isOwnClubAdmin} />}
                        {activeTab === 'calendar' && <TabCalendar clubId={club.id} isOwnClubAdmin={isOwnClubAdmin} />}
                    </div>
                )}
                centerClassName="club-profile-center p-0"
                rightClassName="club-profile-right px-4 py-5"
                right={(
                    <ClubOpportunities
                        club={club}
                        onOpenModule={() => setActiveTab('opportunities')}
                        showOpportunityBoard
                    />
                )}
            />

            {isChallengeModalOpen && (
                <MatchInviteModal
                    sourceClubId={myClubId as number}
                    targetClubId={club.id}
                    targetClubName={club.name}
                    onClose={() => setIsChallengeModalOpen(false)}
                    onSubmit={handleChallengeSubmit}
                />
            )}

            {isManageClubOpen && (
                <ClubManagementModal
                    clubId={club.id}
                    clubName={club.name}
                    currentRole={ownClubRole ?? null}
                    initialTab={requestedManagementTab}
                    onClose={closeManageClub}
                    onSquadCreated={() => setSquadsRefreshKey((current) => current + 1)}
                    onDataChanged={() => {
                        void fetchClubData();
                        void fetchUserContext();
                        setSquadsRefreshKey((current) => current + 1);
                    }}
                    onMembershipLeft={handleMembershipLeft}
                />
            )}

            {isMessageModalOpen && (
                <ClubMessageModal clubName={club.name} options={communicationOptions} onClose={() => setIsMessageModalOpen(false)} />
            )}
        </div>
    );
};
