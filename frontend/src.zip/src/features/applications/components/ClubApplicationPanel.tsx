import { useState } from 'react';
import { ClipboardCheck, Loader2, Send, XCircle } from 'lucide-react';
import { cancelClubApplication, createClubApplication } from '../../clubs/api';
import {
    clubApplicationStatusLabel,
    clubRoleLabel,
    type ClubMembershipRole,
    type ClubRelationshipState
} from '../../clubs/domain';
import { extractApiErrorMessage } from '../../../utils/apiError';
import { StatusBadge } from '../../../components/ui/StatusBadge';

interface ClubApplicationPanelProps {
    clubId: number;
    clubName: string;
    isAuthenticated: boolean;
    relationshipState?: ClubRelationshipState | null;
    pendingApplicationId?: number | null;
    pendingApplicationRole?: ClubMembershipRole | null;
    activeClubId?: number | null;
    onOpenInvites: () => void;
    onSignIn: () => void;
    onStateChange: (nextState: {
        relationshipState: ClubRelationshipState;
        pendingApplicationId?: number | null;
        pendingApplicationRole?: ClubMembershipRole | null;
    }) => void;
}

export const ClubApplicationPanel = ({
    clubId,
    clubName,
    isAuthenticated,
    relationshipState,
    pendingApplicationId,
    pendingApplicationRole,
    activeClubId,
    onOpenInvites,
    onSignIn,
    onStateChange
}: ClubApplicationPanelProps) => {
    const [requestedRole, setRequestedRole] = useState<Extract<ClubMembershipRole, 'COACH' | 'PLAYER'>>('PLAYER');
    const [message, setMessage] = useState('');
    const [pendingKey, setPendingKey] = useState<'apply' | 'cancel' | null>(null);
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const [successMessage, setSuccessMessage] = useState<string | null>(null);

    const belongsToAnotherClub = activeClubId != null && activeClubId !== clubId;

    const handleApply = async () => {
        setPendingKey('apply');
        setErrorMessage(null);
        setSuccessMessage(null);

        try {
            const response = await createClubApplication(clubId, requestedRole, message.trim() || null);
            onStateChange({
                relationshipState: 'APPLIED',
                pendingApplicationId: response.applicationId,
                pendingApplicationRole: requestedRole
            });
            setSuccessMessage(`Application sent to ${clubName}.`);
        } catch (error) {
            setErrorMessage(extractApiErrorMessage(error, 'Failed to submit club application.'));
        } finally {
            setPendingKey(null);
        }
    };

    const handleCancel = async () => {
        if (!pendingApplicationId) {
            return;
        }

        setPendingKey('cancel');
        setErrorMessage(null);
        setSuccessMessage(null);

        try {
            await cancelClubApplication(clubId, pendingApplicationId);
            onStateChange({
                relationshipState: 'NONE',
                pendingApplicationId: null,
                pendingApplicationRole: null
            });
            setSuccessMessage('Application cancelled.');
        } catch (error) {
            setErrorMessage(extractApiErrorMessage(error, 'Failed to cancel club application.'));
        } finally {
            setPendingKey(null);
        }
    };

    return (
        <section className="theme-surface theme-border rounded-2xl border px-5 py-4 shadow-lg dark:shadow-[0_12px_28px_rgba(0,0,0,0.2)]">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                    <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-600 dark:text-emerald-400">
                        <ClipboardCheck className="h-3.5 w-3.5" />
                        Club Application
                    </div>
                    <h3 className="mt-4 text-lg font-black uppercase tracking-tight text-slate-900 dark:text-white">
                        Interested in joining this club?
                    </h3>
                    <p className="mt-2 text-sm font-medium text-slate-600 dark:text-slate-300">
                        Send a role-specific application here, or review an existing invite if the club already reached out.
                    </p>
                </div>

                {relationshipState === 'APPLIED' && (
                    <StatusBadge tone="info">{clubApplicationStatusLabel('PENDING')}</StatusBadge>
                )}
            </div>

            {errorMessage && (
                <div className="mt-4 rounded-xl border border-rose-500/20 bg-rose-500/10 px-4 py-3 text-sm font-semibold text-rose-700 dark:text-rose-300">
                    {errorMessage}
                </div>
            )}

            {successMessage && (
                <div className="mt-4 rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                    {successMessage}
                </div>
            )}

            {!isAuthenticated ? (
                <div className="mt-5 rounded-2xl border border-slate-300 bg-slate-50 px-4 py-4 dark:border-slate-700 dark:bg-slate-900/50">
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
                        Sign in to apply for a role with {clubName} or review any club invitations linked to your account.
                    </p>
                    <button
                        type="button"
                        onClick={onSignIn}
                        className="mt-4 inline-flex items-center gap-2 rounded-xl border-2 border-slate-900 bg-emerald-600 px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] text-white shadow-[4px_4px_0px_0px_#020617] transition-all hover:bg-emerald-500 active:translate-y-0.5 active:shadow-none"
                    >
                        Sign In To Continue
                    </button>
                </div>
            ) : relationshipState === 'INVITED' ? (
                <div className="mt-5 rounded-2xl border border-sky-500/20 bg-sky-500/10 px-4 py-4">
                    <div className="flex flex-wrap items-center gap-2">
                        <StatusBadge tone="info">Invited</StatusBadge>
                        <p className="text-sm font-semibold text-sky-800 dark:text-sky-300">
                            This club already invited you. Review that invite instead of submitting an application.
                        </p>
                    </div>
                    <button
                        type="button"
                        onClick={onOpenInvites}
                        className="mt-4 inline-flex items-center gap-2 rounded-xl border border-slate-900 bg-slate-200 px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-900 shadow-[4px_4px_0px_0px_#020617] transition-all hover:bg-slate-300 active:translate-y-0.5 active:shadow-none dark:bg-slate-800 dark:text-white dark:hover:bg-slate-700"
                    >
                        Review Invite
                    </button>
                </div>
            ) : relationshipState === 'APPLIED' && pendingApplicationId ? (
                <div className="mt-5 rounded-2xl border border-slate-300 bg-slate-50 px-4 py-4 dark:border-slate-700 dark:bg-slate-900/50">
                    <div className="flex flex-wrap items-center gap-2">
                        <StatusBadge tone="info">{clubApplicationStatusLabel('PENDING')}</StatusBadge>
                        {pendingApplicationRole && (
                            <StatusBadge tone="neutral">{clubRoleLabel(pendingApplicationRole)}</StatusBadge>
                        )}
                    </div>
                    <p className="mt-3 text-sm font-medium text-slate-600 dark:text-slate-300">
                        Your application is waiting for club review. You can cancel it while it remains pending.
                    </p>
                    <button
                        type="button"
                        onClick={() => void handleCancel()}
                        disabled={pendingKey === 'cancel'}
                        className="mt-4 inline-flex items-center gap-2 rounded-xl border border-rose-500/20 bg-rose-500/10 px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] text-rose-700 transition-colors hover:bg-rose-500 hover:text-white disabled:cursor-not-allowed disabled:opacity-60 dark:text-rose-300"
                    >
                        {pendingKey === 'cancel' ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />}
                        Cancel Application
                    </button>
                </div>
            ) : belongsToAnotherClub ? (
                <div className="mt-5 rounded-2xl border border-slate-300 bg-slate-50 px-4 py-4 dark:border-slate-700 dark:bg-slate-900/50">
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
                        Applications stay closed while this account already has an active club membership elsewhere.
                    </p>
                    <button
                        type="button"
                        onClick={onOpenInvites}
                        className="mt-4 inline-flex items-center gap-2 rounded-xl border border-slate-900 bg-slate-200 px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-900 shadow-[4px_4px_0px_0px_#020617] transition-all hover:bg-slate-300 active:translate-y-0.5 active:shadow-none dark:bg-slate-800 dark:text-white dark:hover:bg-slate-700"
                    >
                        Open My Club
                    </button>
                </div>
            ) : (
                <div className="mt-5 space-y-4">
                <div className="grid gap-4 md:grid-cols-[220px_1fr]">
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                                Requested Role
                            </label>
                            <select
                                value={requestedRole}
                                onChange={(event) => setRequestedRole(event.target.value as Extract<ClubMembershipRole, 'COACH' | 'PLAYER'>)}
                                className="theme-surface-muted theme-border w-full rounded-xl border px-4 py-3 text-sm font-black uppercase tracking-wide text-slate-900 outline-none focus:border-emerald-500 dark:text-white"
                            >
                                <option value="PLAYER">Player</option>
                                <option value="COACH">Coach</option>
                            </select>
                        </div>

                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                                Message
                            </label>
                            <textarea
                                value={message}
                                onChange={(event) => setMessage(event.target.value)}
                                rows={4}
                                maxLength={2000}
                                placeholder="Introduce yourself and explain how you want to contribute."
                                className="theme-surface-muted theme-border w-full rounded-xl border px-4 py-3 text-sm font-medium text-slate-900 outline-none focus:border-emerald-500 dark:text-white"
                            />
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={() => void handleApply()}
                        disabled={pendingKey === 'apply'}
                        className="inline-flex items-center gap-2 rounded-xl border-2 border-slate-900 bg-emerald-600 px-5 py-3 text-[11px] font-black uppercase tracking-[0.18em] text-white shadow-[4px_4px_0px_0px_#020617] transition-all hover:bg-emerald-500 active:translate-y-0.5 active:shadow-none disabled:cursor-not-allowed disabled:opacity-70"
                    >
                        {pendingKey === 'apply' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                        Send Application
                    </button>
                </div>
            )}
        </section>
    );
};
