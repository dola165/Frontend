import { Link, useLocation } from 'react-router-dom';
import {
    BellRing,
    Building2,
    CalendarDays,
    Home,
    Map as MapIcon,
    Menu,
    MessageSquare,
    Moon,
    Search,
    Shield,
    ShieldCheck,
    Sun,
    User
} from 'lucide-react';
import { NotificationBell } from '../notifications/NotificationBell';
import { resolveNavigationKey } from './navigation';

interface TopNavProps {
    user: { id?: number; username?: string; fullName?: string; role?: string } | null;
    myClubId: number | null;
    darkMode: boolean;
    setDarkMode: (val: boolean) => void;
    handleLogout: () => void;
}

const primaryLinks = [
    {
        id: 'feed',
        path: '/feed',
        label: 'Feed',
        icon: Home
    },
    {
        id: 'map',
        path: '/map',
        label: 'Map',
        icon: MapIcon
    },
    {
        id: 'clubs',
        path: '/clubs',
        label: 'Clubs',
        icon: Shield
    },
    {
        id: 'my-club',
        path: '/my-club',
        label: 'My Club',
        icon: Building2
    },
    {
        id: 'calendar',
        path: '/calendar',
        label: 'Schedule',
        icon: CalendarDays
    },
    {
        id: 'messages',
        path: '/messages',
        label: 'Messages',
        icon: MessageSquare
    },
    {
        id: 'notifications',
        path: '/notifications',
        label: 'Notifications',
        icon: BellRing
    }
];

export const TopNav = ({ user, myClubId, darkMode, setDarkMode, handleLogout }: TopNavProps) => {
    const location = useLocation();
    const activeKey = resolveNavigationKey(location.pathname, myClubId);

    return (
        <nav className="sticky top-0 z-50 border-b border-subtle bg-surface text-primary backdrop-blur">
            <div className="mx-auto flex max-w-[1600px] flex-col px-4 sm:px-6">
                <div className="flex h-14 items-center justify-between gap-4 operational-divider">
                    <div className="flex min-w-0 items-center gap-3">
                        <button
                            type="button"
                            className="inline-flex h-9 w-9 items-center justify-center border border-subtle bg-base text-secondary lg:hidden"
                            aria-label="Open navigation"
                        >
                            <Menu className="h-4 w-4" />
                        </button>
                        <Link to={user ? '/feed' : '/'} className="shrink-0">
                            <div className="flex flex-col leading-none">
                                <span className="text-lg font-black uppercase tracking-[0.28em] accent-primary">Talanti</span>
                                <span className="mt-1 text-[10px] font-black uppercase tracking-[0.2em] text-secondary">
                                    Football Network Ops
                                </span>
                            </div>
                        </Link>
                    </div>

                    <div className="hidden min-w-0 max-w-xl flex-1 items-center justify-center lg:flex">
                        <label className="flex w-full max-w-xl items-center gap-3 border border-subtle bg-base px-4 py-2 text-secondary transition-colors focus-within:border-accent-primary">
                            <Search className="h-4 w-4 shrink-0" />
                            <input
                                type="text"
                                placeholder="Search clubs, players, locations"
                                className="w-full bg-transparent text-sm font-medium text-primary outline-none placeholder:text-muted"
                            />
                        </label>
                    </div>

                    <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
                        <NotificationBell enabled={Boolean(user?.id)} />

                        {user?.role === 'SYSTEM_ADMIN' && (
                            <Link
                                to="/admin"
                                className="hidden items-center gap-1.5 border border-subtle bg-base px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-secondary transition-colors hover:text-primary sm:inline-flex"
                            >
                                <ShieldCheck className="h-3.5 w-3.5 accent-primary" />
                                Admin
                            </Link>
                        )}

                        <button
                            type="button"
                            onClick={() => setDarkMode(!darkMode)}
                            className="inline-flex h-9 w-9 items-center justify-center border border-subtle bg-base text-secondary transition-colors hover:text-primary"
                            aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
                        >
                            {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                        </button>

                        {user ? (
                            <>
                                <Link
                                    to="/account"
                                    className="inline-flex h-9 min-w-9 items-center justify-center border border-subtle bg-base px-2.5 text-[11px] font-black uppercase tracking-[0.16em] text-primary transition-colors hover:border-strong"
                                >
                                    {(user.username || user.fullName || 'U').substring(0, 2).toUpperCase()}
                                </Link>
                                <button
                                    type="button"
                                    onClick={handleLogout}
                                    className="hidden border border-subtle bg-base px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-secondary transition-colors hover:text-primary sm:inline-flex"
                                >
                                    Sign Out
                                </button>
                            </>
                        ) : (
                            <>
                                <Link
                                    to="/login"
                                    className="hidden border border-subtle bg-base px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-secondary transition-colors hover:text-primary sm:inline-flex"
                                >
                                    Sign In
                                </Link>
                                <Link
                                    to="/signup"
                                    className="inline-flex items-center gap-2 border border-accent-primary bg-accent-primary-soft px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] accent-primary transition-colors hover:text-primary"
                                >
                                    <User className="h-3.5 w-3.5" />
                                    Account
                                </Link>
                            </>
                        )}
                    </div>
                </div>

                <div className="scrollbar-hide overflow-x-auto">
                    <div className="flex min-w-max items-stretch gap-6">
                        {primaryLinks.map((item) => {
                            const active = activeKey === item.id;
                            const Icon = item.icon;

                            return (
                                <Link
                                    key={item.path}
                                    to={item.path}
                                    className={`inline-flex h-[38px] items-center gap-2 border-b-2 px-1 text-xs font-black uppercase tracking-[0.18em] transition-colors ${
                                        active
                                            ? 'border-accent-muted text-primary'
                                            : 'border-transparent text-secondary hover:text-primary'
                                    }`}
                                >
                                    <Icon className={`h-3.5 w-3.5 ${active ? 'accent-primary' : ''}`} />
                                    {item.label}
                                </Link>
                            );
                        })}
                    </div>
                </div>
            </div>
        </nav>
    );
};
