import { useRef, useState } from 'react';
import { Camera, Loader2, Send, Video, X } from 'lucide-react';
import { apiClient } from '../../api/axiosConfig';

interface PostComposerProps {
    clubId?: number;
    authorName?: string;
    onPostCreated: () => void;
    contextType?: string;
    contextId?: number;
    compact?: boolean;
    onExpand?: () => void;
}

export const PostComposer = ({
    clubId,
    authorName = 'You',
    onPostCreated,
    compact = false,
    onExpand
}: PostComposerProps) => {
    const [content, setContent] = useState('');
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isExpanded, setIsExpanded] = useState(!compact);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const expandComposer = () => {
        if (!compact || isExpanded) return;
        setIsExpanded(true);
        onExpand?.();
    };

    const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            expandComposer();
            const file = event.target.files[0];
            setSelectedFile(file);
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    const removeFile = () => {
        setSelectedFile(null);
        setPreviewUrl(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleSubmit = async () => {
        if (!content.trim() && !selectedFile) return;
        setIsSubmitting(true);

        try {
            const mediaIds: number[] = [];

            if (selectedFile) {
                const formData = new FormData();
                formData.append('file', selectedFile);
                const mediaResponse = await apiClient.post('/media/upload', formData, {
                    headers: { 'Content-Type': 'multipart/form-data' }
                });
                mediaIds.push(mediaResponse.data.id);
            }

            await apiClient.post('/posts', {
                content,
                clubId: clubId || null,
                isPublic: true,
                mediaIds
            });

            setContent('');
            removeFile();
            onPostCreated();
            if (compact) setIsExpanded(false);
        } catch (error) {
            console.error('Failed to create post', error);
            alert('Failed to publish update.');
        } finally {
            setIsSubmitting(false);
        }
    };

    const wrapperClassName = compact
        ? 'bg-surface border border-subtle rounded-[6px] px-3.5 py-3 shadow-panel'
        : 'bg-surface border border-subtle rounded-[18px] px-5 py-4 shadow-panel';

    return (
        <section className={wrapperClassName}>
            <div className={`flex items-start gap-3 ${isExpanded || previewUrl ? 'mb-3' : ''}`}>
                <div className={`flex h-9 w-9 shrink-0 items-center justify-center border border-subtle bg-base text-sm font-black uppercase text-primary ${compact ? 'rounded-[4px] text-[10px]' : 'rounded-full'}`}>
                    {authorName.substring(0, 2).toUpperCase()}
                </div>
                <textarea
                    value={content}
                    onChange={(event) => setContent(event.target.value)}
                    onFocus={expandComposer}
                    onClick={expandComposer}
                    placeholder={clubId ? 'Publish a club update...' : 'Share an operational update...'}
                    className={`flex-1 resize-none border border-subtle bg-base px-3 py-2.5 text-sm text-primary outline-none placeholder:text-muted focus:border-accent-primary ${compact ? 'rounded-[4px]' : 'rounded-[14px]'} ${isExpanded ? 'min-h-[92px]' : 'min-h-[44px]'}`}
                    rows={compact ? (isExpanded ? 3 : 1) : (content.split('\n').length > 2 ? 3 : 1)}
                />
                <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={isSubmitting || (!content.trim() && !selectedFile)}
                    className={`inline-flex items-center justify-center gap-2 border border-accent-primary bg-accent-primary-soft accent-primary disabled:opacity-50 ${compact ? 'h-11 w-11 rounded-[4px]' : 'rounded-[14px] px-5 py-3'}`}
                >
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    {!compact && 'Post'}
                </button>
            </div>

            {previewUrl && (
                <div className={`relative mb-3 ml-[48px] w-fit overflow-hidden border border-subtle ${compact ? 'rounded-[4px]' : 'rounded-[14px]'}`}>
                    <img src={previewUrl} alt="Upload preview" className={`${compact ? 'max-h-36' : 'max-h-48'} object-cover`} />
                    <button type="button" onClick={removeFile} className={`absolute right-2 top-2 inline-flex h-8 w-8 items-center justify-center bg-black/60 text-white ${compact ? 'rounded-[4px]' : 'rounded-full'}`}>
                        <X className="h-4 w-4" />
                    </button>
                </div>
            )}

            {isExpanded && (
                <div className="ml-[48px] flex flex-wrap items-center justify-between gap-3 border-t border-subtle pt-3">
                    <div className="flex gap-2">
                        <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" accept="image/*,video/*" />
                        <button type="button" onClick={() => fileInputRef.current?.click()} className={`inline-flex items-center gap-2 border border-subtle bg-base px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-primary ${compact ? 'rounded-[4px]' : 'rounded-[12px]'}`}>
                            <Camera className="h-4 w-4 accent-primary" />
                            Photo
                        </button>
                        <button type="button" onClick={() => fileInputRef.current?.click()} className={`inline-flex items-center gap-2 border border-subtle bg-base px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-primary ${compact ? 'rounded-[4px]' : 'rounded-[12px]'}`}>
                            <Video className="h-4 w-4 accent-primary" />
                            Video
                        </button>
                    </div>

                    {compact && <p className="text-[11px] font-black uppercase tracking-[0.16em] text-secondary">Composer Expanded</p>}
                </div>
            )}
        </section>
    );
};
