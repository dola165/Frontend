import { CheckCircle2, ExternalLink, MessageSquare, Phone, ShieldCheck, Store, Users } from 'lucide-react';
import type { ClubProfile } from '../../pages/ClubProfilePage';
import { buildClubProfileLinks, getDomainLabel, summarizeClubTrust, toPhoneHref, toWhatsappHref } from './clubProfileInfo';

interface ClubProfileInfoPanelProps {
    club: ClubProfile;
}

export const ClubProfileInfoPanel = ({ club }: ClubProfileInfoPanelProps) => {
    const phoneHref = toPhoneHref(club.whatsappNumber);
    const whatsappHref = toWhatsappHref(club.whatsappNumber);
    const publicLinks = buildClubProfileLinks(club);
    const trustCount = club.trustedByClubs.length;

    return (
        <aside className="club-info-panel-shell lg:sticky lg:top-[calc(var(--app-header-height)+64px)]">
            <section className="club-info-panel rounded-[4px]">
                <div className="border-b border-subtle px-4 py-4">
                    <p className="text-[11px] font-black uppercase tracking-[0.18em] text-secondary">Club Information</p>
                    <p className="mt-2 text-sm font-black uppercase tracking-[0.12em] text-primary">
                        Contact, public links, and legitimacy at a glance
                    </p>
                </div>

                <div className="club-info-panel__body space-y-5 px-4 py-4">
                    <section>
                        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-secondary">
                            <Phone className="h-4 w-4 text-[color:var(--club-tone-green)]" />
                            Public Contact
                        </div>
                        <p className="mt-3 text-xl font-black uppercase tracking-[0.06em] text-primary">
                            {club.whatsappNumber || 'Not published'}
                        </p>
                        <p className="mt-2 text-sm leading-6 text-secondary">
                            {club.whatsappNumber ? 'Use this as the main direct line for fast club contact.' : 'No public direct phone or WhatsApp line is published yet.'}
                        </p>

                        <div className="mt-4 flex flex-wrap gap-2">
                            {phoneHref ? (
                                <a href={phoneHref} className="club-info-link-pill club-tone-green inline-flex items-center gap-2 rounded-[999px] px-3 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-primary">
                                    <Phone className="h-3.5 w-3.5" />
                                    Call
                                </a>
                            ) : null}
                            {whatsappHref ? (
                                <a href={whatsappHref} target="_blank" rel="noopener noreferrer" className="club-info-link-pill club-tone-green inline-flex items-center gap-2 rounded-[999px] px-3 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-primary">
                                    <MessageSquare className="h-3.5 w-3.5" />
                                    WhatsApp
                                </a>
                            ) : null}
                        </div>
                    </section>

                    <section className="border-t border-subtle pt-5">
                        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-secondary">
                            <Store className="h-4 w-4 text-[color:var(--club-tone-blue)]" />
                            Public Links
                        </div>
                        <p className="mt-2 text-sm leading-6 text-secondary">
                            Facebook, WhatsApp, store, fundraising, and other public entry points.
                        </p>

                        <div className="mt-4 flex flex-wrap gap-2">
                            {publicLinks.length > 0 ? publicLinks.map((link) => (
                                <a
                                    key={`${link.label}-${link.href}`}
                                    href={link.href}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className={`club-info-link-pill ${link.toneClassName} inline-flex items-center gap-2 rounded-[999px] px-3 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-primary`}
                                >
                                    <span>{link.label}</span>
                                    <ExternalLink className="h-3.5 w-3.5" />
                                </a>
                            )) : (
                                <p className="text-sm leading-6 text-secondary">No public links are published yet.</p>
                            )}
                        </div>

                        {publicLinks.length > 0 ? (
                            <p className="mt-4 text-[11px] font-black uppercase tracking-[0.16em] text-secondary">
                                {publicLinks.map((link) => getDomainLabel(link.href)).join(' | ')}
                            </p>
                        ) : null}
                    </section>

                    <section className="border-t border-subtle pt-5">
                        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-secondary">
                            {trustCount > 0 ? <Users className="h-4 w-4 text-[color:var(--club-tone-cyan)]" /> : <ShieldCheck className="h-4 w-4 text-[color:var(--club-tone-cyan)]" />}
                            Legitimacy
                        </div>

                        <div className="mt-4 flex flex-wrap gap-2">
                            <span className="club-info-link-pill club-tone-cyan inline-flex items-center gap-2 rounded-[999px] px-3 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-primary">
                                <CheckCircle2 className="h-3.5 w-3.5" />
                                {club.statusLabel || (club.isOfficial ? 'Verified' : 'Reviewing')}
                            </span>
                            {trustCount > 0 ? (
                                <span className="club-info-link-pill club-tone-blue inline-flex items-center gap-2 rounded-[999px] px-3 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-primary">
                                    <Users className="h-3.5 w-3.5" />
                                    {trustCount} recommendation{trustCount === 1 ? '' : 's'}
                                </span>
                            ) : null}
                        </div>

                        <p className="mt-4 text-sm leading-6 text-secondary">
                            {summarizeClubTrust(club)}
                        </p>

                        {club.trustedByClubs.length > 0 ? (
                            <div className="mt-4 flex flex-wrap gap-2">
                                {club.trustedByClubs.slice(0, 4).map((trustedClub) => (
                                    <span key={trustedClub.clubId} className="club-info-link-pill club-tone-cyan inline-flex items-center gap-2 rounded-[999px] px-3 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-primary">
                                        {trustedClub.clubName}
                                    </span>
                                ))}
                            </div>
                        ) : null}
                    </section>
                </div>
            </section>
        </aside>
    );
};
